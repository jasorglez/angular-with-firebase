import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-disputes',
  templateUrl: './disputes.component.html',
  styleUrls: ['./disputes.component.css']
})
export class DisputesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
